//
//  AppDelegate.h
//  BASee
//
//  Created by Matt Babasick on 4/16/16.
//  Copyright © 2016 Matt Babasick. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

