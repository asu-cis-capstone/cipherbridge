//
//  ResultsViewController.m
//  BASee
//
//  Created by Matt Babasick on 4/16/16.
//  Copyright © 2016 Matt Babasick. All rights reserved.
//

#import "ResultsViewController.h"

@interface ResultsViewController ()

@property (weak, nonatomic) IBOutlet UILabel *severityLabel;
@property (weak, nonatomic) IBOutlet UITextView *descriptionTextView;
@property (weak, nonatomic) IBOutlet UIButton *color;

@end

@implementation ResultsViewController

- (void) viewDidLoad
{
    switch (self.severity)
    {
        case 1:
        case 2:
            self.severityLabel.text = @"LOW";
            [self.color setBackgroundColor:UIColorFromRGB(0x00E627)];
            self.descriptionTextView.text = @"You are at or below the legal limit for BAC.  Impairment is minimal, and driving with an intoxication level below 0.08 is legal in many states.";
            break;
        case 3:
        case 4:
            self.severityLabel.text = @"MODERATE";
            [self.color setBackgroundColor:UIColorFromRGB(0xE69900)];
            self.descriptionTextView.text = @"Do not drive.  This level indicates significant impairment, which may affect your motor functions and speech.  Breathing slows and consciousness begins to fade as intoxication increases.";
            break;
        case 5:
            self.severityLabel.text = @"SEVERE";
            [self.color setBackgroundColor:UIColorFromRGB(0xE60000)];
            self.descriptionTextView.text = @"Consider seeking medical help, and stop drinking immediately.  This level of intoxication approaches alcohol poisoning.  Impairment significantly affects your breathing rate, as well as the ability to remain conscious.";
            break;
        default:
            break;
    }
}

@end
