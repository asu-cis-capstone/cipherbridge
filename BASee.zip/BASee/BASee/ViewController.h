//
//  ViewController.h
//  BASee
//
//  Created by Matt Babasick on 4/16/16.
//  Copyright © 2016 Matt Babasick. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property int severity;
@property double bac;

@end

