//
//  ViewController.m
//  BASee
//
//  Created by Matt Babasick on 4/16/16.
//  Copyright © 2016 Matt Babasick. All rights reserved.
//

#import "ViewController.h"
#import "ResultsViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *connectLabel;
@property (weak, nonatomic) IBOutlet UILabel *bacLabel;
@property (weak, nonatomic) IBOutlet UIButton *resultsButton;
@property (weak, nonatomic) IBOutlet UIButton *circle;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.bacLabel.hidden = YES;
    self.resultsButton.hidden = YES;
    self.circle.hidden = YES;
    [self.view sendSubviewToBack:self.circle];
    
    double sec = 3.0;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void)
    {
        self.connectLabel.hidden = YES;
    });
    
    sec = 4.0;
    popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void)
    {
        self.connectLabel.text = @"Analyzing results...";
        self.connectLabel.hidden = NO;
    });
    
    sec = 7.0;
    popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void)
    {
        self.connectLabel.hidden = YES;
    });
    
    sec = 8.0;
    popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void)
    {
        self.connectLabel.text = @"Your BAC level is:";
        self.connectLabel.hidden = NO;
        
        self.severity = (arc4random() % 5) + 1;
        self.bac = 0;
        switch (self.severity)
        {
            case 1:
            case 2:
                self.bac = (arc4random() % 8) + 1;
                [self.circle setBackgroundImage:[UIImage imageNamed:@"circle1.png"] forState:UIControlStateNormal];
                break;
            case 3:
            case 4:
                self.bac = (arc4random() % 12) + 9;
                [self.circle setBackgroundImage:[UIImage imageNamed:@"circle2.png"] forState:UIControlStateNormal];
                break;
            case 5:
                self.bac = (arc4random() % 25) + 25;
                [self.circle setBackgroundImage:[UIImage imageNamed:@"circle3.png"] forState:UIControlStateNormal];
                break;
            default:
                break;
        }
        self.bac /= 100;
        
        self.bacLabel.text = [NSString stringWithFormat:@"%.02f", self.bac];
        self.bacLabel.hidden = NO;
        self.circle.hidden = NO;
    });
    
    sec = 9.0;
    popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void)
    {
        self.resultsButton.hidden = NO;
    });
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    ResultsViewController *vc = [segue destinationViewController];     // get destination view
    vc.severity = self.severity;
    vc.bac = self.bac;
}

@end
